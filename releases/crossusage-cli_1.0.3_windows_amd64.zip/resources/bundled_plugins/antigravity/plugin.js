(function () {
  var LS_SERVICE = "exa.language_server_pb.LanguageServerService"
  var CLOUD_CODE_URLS = [
    "https://daily-cloudcode-pa.googleapis.com",
    "https://cloudcode-pa.googleapis.com",
  ]
  var FETCH_MODELS_PATH = "/v1internal:fetchAvailableModels"
  var LOAD_CODE_ASSIST_PATH = "/v1internal:loadCodeAssist"
  var GOOGLE_OAUTH_URL = "https://oauth2.googleapis.com/token"
  var GOOGLE_CLIENT_ID = "1071006060591-tmhssin2h21lcre235vtolojh4g403ep.apps.googleusercontent.com"
  var GOOGLE_CLIENT_SECRET = "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"
  var PLAN_CACHE_MAX_AGE_MS = 30 * 60 * 1000
  var CC_MODEL_BLACKLIST = {
    "MODEL_CHAT_20706": true,
    "MODEL_CHAT_23310": true,
    "MODEL_GOOGLE_GEMINI_2_5_FLASH": true,
    "MODEL_GOOGLE_GEMINI_2_5_FLASH_THINKING": true,
    "MODEL_GOOGLE_GEMINI_2_5_FLASH_LITE": true,
    "MODEL_GOOGLE_GEMINI_2_5_PRO": true,
    "MODEL_PLACEHOLDER_M19": true,
    "MODEL_PLACEHOLDER_M9": true,
    "MODEL_PLACEHOLDER_M12": true,
  }
  // --- Protobuf wire-format decoder ---

  function readVarint(s, pos) {
    var v = 0
    var shift = 0
    while (pos < s.length) {
      var b = s.charCodeAt(pos++)
      v += (b & 0x7f) * Math.pow(2, shift)
      if ((b & 0x80) === 0) return { v: v, p: pos }
      shift += 7
    }
    return null
  }

  function readFields(s) {
    var fields = {}
    var pos = 0
    while (pos < s.length) {
      var tag = readVarint(s, pos)
      if (!tag) break
      pos = tag.p
      var fieldNum = Math.floor(tag.v / 8)
      var wireType = tag.v % 8
      if (wireType === 0) {
        var val = readVarint(s, pos)
        if (!val) break
        fields[fieldNum] = { type: 0, value: val.v }
        pos = val.p
      } else if (wireType === 2) {
        var len = readVarint(s, pos)
        if (!len) break
        pos = len.p
        fields[fieldNum] = { type: 2, data: s.substring(pos, pos + len.v) }
        pos += len.v
      } else {
        break
      }
    }
    return fields
  }

  // --- SQLite credential reading ---

  function getAntigravityDbPath(ctx) {
    var home = ctx.host.fs.homeDir
    if (!home && ctx.app && ctx.app.appDataDir) {
      var m = String(ctx.app.appDataDir).match(/^(.+)\/\.local\/share\/[^/]+$/)
      if (m) home = m[1]
    }
    var macPath = "~/Library/Application Support/Antigravity/User/globalStorage/state.vscdb"
    var linuxPath = "~/.config/Antigravity/User/globalStorage/state.vscdb"
    var winPath = "~/AppData/Roaming/Antigravity/User/globalStorage/state.vscdb"
    if (ctx.host.fs.exists(macPath)) return macPath
    if (ctx.host.fs.exists(linuxPath)) return linuxPath
    if (ctx.host.fs.exists(winPath)) return winPath
    if (home) { 
      var linuxAbs = home + "/.config/Antigravity/User/globalStorage/state.vscdb"
      var macAbs = home + "/Library/Application Support/Antigravity/User/globalStorage/state.vscdb"
      var winAbs = home + "/AppData/Roaming/Antigravity/User/globalStorage/state.vscdb"
      if (ctx.host.fs.exists(linuxAbs)) return linuxAbs
      if (ctx.host.fs.exists(macAbs)) return macAbs
      if (ctx.host.fs.exists(winAbs)) return winAbs
    }
    return macPath
  }

  function loadAuthStatus(ctx) {
    try {
      var dbPath = getAntigravityDbPath(ctx)
      var rows = ctx.host.sqlite.query(
        dbPath,
        "SELECT value FROM ItemTable WHERE key = 'antigravityAuthStatus' LIMIT 1"
      )
      var parsed = ctx.util.tryParseJson(rows)
      if (!parsed || !parsed.length || !parsed[0].value) return null
      var auth = ctx.util.tryParseJson(parsed[0].value)
      if (!auth || typeof auth !== "object") return null
      return auth
    } catch (e) {
      ctx.host.log.warn("failed to read auth from antigravity DB: " + String(e))
      return null
    }
  }

  function loadProtoTokens(ctx) {
    try {
      var dbPath = getAntigravityDbPath(ctx)
      var rows = ctx.host.sqlite.query(
        dbPath,
        "SELECT value FROM ItemTable WHERE key = 'jetskiStateSync.agentManagerInitState' LIMIT 1"
      )
      var parsed = ctx.util.tryParseJson(rows)
      if (!parsed || !parsed.length || !parsed[0].value) return null
      var raw = ctx.base64.decode(parsed[0].value)
      var outer = readFields(raw)
      if (!outer[6] || outer[6].type !== 2) return null
      var inner = readFields(outer[6].data)
      var accessToken = (inner[1] && inner[1].type === 2) ? inner[1].data : null
      var refreshToken = (inner[3] && inner[3].type === 2) ? inner[3].data : null
      var expirySeconds = null
      if (inner[4] && inner[4].type === 2) {
        var ts = readFields(inner[4].data)
        if (ts[1] && ts[1].type === 0) expirySeconds = ts[1].value
      }
      if (!accessToken) return null
      return { accessToken: accessToken, refreshToken: refreshToken, expirySeconds: expirySeconds }
    } catch (e) {
      ctx.host.log.warn("failed to read proto tokens from antigravity DB: " + String(e))
      return null
    }
  }

  // --- Google OAuth token refresh ---

  function refreshAccessToken(ctx, refreshTokenValue) {
    if (!refreshTokenValue) {
      ctx.host.log.warn("refresh skipped: no refresh token")
      return null
    }
    ctx.host.log.info("attempting Google OAuth token refresh")
    try {
      var resp = ctx.host.http.request({
        method: "POST",
        url: GOOGLE_OAUTH_URL,
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        bodyText:
          "client_id=" + encodeURIComponent(GOOGLE_CLIENT_ID) +
          "&client_secret=" + encodeURIComponent(GOOGLE_CLIENT_SECRET) +
          "&refresh_token=" + encodeURIComponent(refreshTokenValue) +
          "&grant_type=refresh_token",
        timeoutMs: 15000,
      })
      if (resp.status < 200 || resp.status >= 300) {
        ctx.host.log.warn("Google OAuth refresh returned status: " + resp.status)
        return null
      }
      var body = ctx.util.tryParseJson(resp.bodyText)
      if (!body || !body.access_token) {
        ctx.host.log.warn("Google OAuth refresh response missing access_token")
        return null
      }
      var expiresIn = (typeof body.expires_in === "number") ? body.expires_in : 3600
      cacheToken(ctx, body.access_token, expiresIn)
      return body.access_token
    } catch (e) {
      ctx.host.log.warn("Google OAuth refresh failed: " + String(e))
      return null
    }
  }

  // --- Token cache ---

  function loadCachedToken(ctx) {
    var path = ctx.app.pluginDataDir + "/auth.json"
    try {
      if (!ctx.host.fs.exists(path)) return null
      var data = ctx.util.tryParseJson(ctx.host.fs.readText(path))
      if (!data || !data.accessToken || !data.expiresAtMs) return null
      if (data.expiresAtMs <= Date.now()) return null
      return data.accessToken
    } catch (e) {
      ctx.host.log.warn("failed to read cached token: " + String(e))
      return null
    }
  }

  function cacheToken(ctx, accessToken, expiresInSeconds) {
    var path = ctx.app.pluginDataDir + "/auth.json"
    try {
      ctx.host.fs.writeText(path, JSON.stringify({
        accessToken: accessToken,
        expiresAtMs: Date.now() + (expiresInSeconds || 3600) * 1000,
      }))
    } catch (e) {
      ctx.host.log.warn("failed to cache refreshed token: " + String(e))
    }
  }

  function normalizeAccountId(value) {
    if (typeof value !== "string") return null
    var normalized = value.trim().toLowerCase()
    return normalized || null
  }

  function loadCachedPlan(ctx, accountId) {
    if (!accountId) return null
    var path = ctx.app.pluginDataDir + "/plan.json"
    try {
      if (!ctx.host.fs.exists(path)) return null
      var data = ctx.util.tryParseJson(ctx.host.fs.readText(path))
      if (!data || typeof data.plan !== "string" || !data.plan || !data.updatedAtMs) return null
      var updatedAtMs = Number(data.updatedAtMs)
      if (!Number.isFinite(updatedAtMs)) return null
      if (updatedAtMs > Date.now()) return null
      if (Date.now() - updatedAtMs > PLAN_CACHE_MAX_AGE_MS) return null
      if (normalizeAccountId(data.accountId) !== accountId) return null
      return data.plan
    } catch (e) {
      ctx.host.log.warn("failed to read cached plan: " + String(e))
      return null
    }
  }

  function cachePlan(ctx, plan, accountId) {
    if (typeof plan !== "string" || !plan || !accountId) return
    var path = ctx.app.pluginDataDir + "/plan.json"
    try {
      ctx.host.fs.writeText(path, JSON.stringify({
        plan: plan,
        accountId: accountId,
        updatedAtMs: Date.now(),
      }))
    } catch (e) {
      ctx.host.log.warn("failed to cache plan: " + String(e))
    }
  }

  function pushUniqueToken(tokens, token) {
    if (typeof token !== "string" || !token) return
    for (var i = 0; i < tokens.length; i++) {
      if (tokens[i] === token) return
    }
    tokens.push(token)
  }

  function collectTokens(ctx, apiKey, proto) {
    var tokens = []
    if (proto && proto.accessToken) {
      if (!proto.expirySeconds || proto.expirySeconds > Math.floor(Date.now() / 1000)) {
        pushUniqueToken(tokens, proto.accessToken)
      }
    }

    pushUniqueToken(tokens, loadCachedToken(ctx))
    pushUniqueToken(tokens, apiKey)
    return tokens
  }

  // --- LS discovery ---

  function discoverLs(ctx) {
    // "language_server" matches both language_server_macos and language_server_linux
    return ctx.host.ls.discover({
      processName: "language_server",
      markers: ["antigravity"],
      csrfFlag: "--csrf_token",
      portFlag: "--extension_server_port",
    })
  }

  function probePort(ctx, scheme, port, csrf) {
    ctx.host.http.request({
      method: "POST",
      url: scheme + "://127.0.0.1:" + port + "/" + LS_SERVICE + "/GetUnleashData",
      headers: {
        "Content-Type": "application/json",
        "Connect-Protocol-Version": "1",
        "x-codeium-csrf-token": csrf,
      },
      bodyText: JSON.stringify({
        context: {
          properties: {
            devMode: "false",
            extensionVersion: "unknown",
            ide: "antigravity",
            ideVersion: "unknown",
            os: "macos",
          },
        },
      }),
      timeoutMs: 5000,
      dangerouslyIgnoreTls: scheme === "https",
    })
    // Any HTTP response means this port is alive (even 400 validation errors).
    return true
  }

  function findWorkingPort(ctx, discovery) {
    var ports = discovery.ports || []
    for (var i = 0; i < ports.length; i++) {
      var port = ports[i]
      // Try HTTPS first (LS may use self-signed cert), then HTTP
      try { if (probePort(ctx, "https", port, discovery.csrf)) return { port: port, scheme: "https" } } catch (e) { /* ignore */ }
      try { if (probePort(ctx, "http", port, discovery.csrf)) return { port: port, scheme: "http" } } catch (e) { /* ignore */ }
      ctx.host.log.info("port " + port + " probe failed on both schemes")
    }
    if (discovery.extensionPort) return { port: discovery.extensionPort, scheme: "http" }
    return null
  }

  function callLs(ctx, port, scheme, csrf, method, body) {
    var resp = ctx.host.http.request({
      method: "POST",
      url: scheme + "://127.0.0.1:" + port + "/" + LS_SERVICE + "/" + method,
      headers: {
        "Content-Type": "application/json",
        "Connect-Protocol-Version": "1",
        "x-codeium-csrf-token": csrf,
      },
      bodyText: JSON.stringify(body || {}),
      timeoutMs: 10000,
      dangerouslyIgnoreTls: scheme === "https",
    })
    if (resp.status < 200 || resp.status >= 300) {
      ctx.host.log.warn("callLs " + method + " returned " + resp.status)
      return null
    }
    return ctx.util.tryParseJson(resp.bodyText)
  }

  // --- Line builders ---

  function normalizeLabel(label) {
    // "Gemini 3 Pro (High)" -> "Gemini 3 Pro"
    return label.replace(/\s*\([^)]*\)\s*$/, "").trim()
  }

  /** Gemini Pro / Flash stay pooled; every other model gets its own line (Claude Sonnet 4.6, GPT-OSS 120B, …). */
  function modelKeyAndDisplay(normalizedLabel) {
    var lower = normalizedLabel.toLowerCase()
    if (lower.indexOf("gemini") !== -1 && lower.indexOf("pro") !== -1) {
      return { key: "pool:gemini_pro", display: "Gemini Pro" }
    }
    if (lower.indexOf("gemini") !== -1 && lower.indexOf("flash") !== -1) {
      return { key: "pool:gemini_flash", display: "Gemini Flash" }
    }
    return { key: "model:" + normalizedLabel, display: normalizedLabel }
  }

  function modelSortKey(label) {
    var lower = label.toLowerCase()
    // Gemini Pro variants first, then other Gemini, then Claude Opus, then other Claude, then GPT-OSS, then rest
    if (lower.indexOf("gemini") !== -1 && lower.indexOf("pro") !== -1) return "0a_" + label
    if (lower.indexOf("gemini") !== -1) return "0b_" + label
    if (lower.indexOf("claude") !== -1 && lower.indexOf("opus") !== -1) return "1a_" + label
    if (lower.indexOf("claude") !== -1) return "1b_" + label
    if (lower.indexOf("gpt") !== -1 || lower.indexOf("oss") !== -1) return "1c_" + label
    return "2_" + label
  }

  var QUOTA_PERIOD_MS = 5 * 60 * 60 * 1000 // 5 hours

  function modelLine(ctx, label, remainingFraction, resetTime) {
    var clamped = Math.max(0, Math.min(1, remainingFraction))
    var used = Math.round((1 - clamped) * 100)
    return ctx.line.progress({
      label: label,
      used: used,
      limit: 100,
      format: { kind: "percent" },
      resetsAt: resetTime || undefined,
      periodDurationMs: QUOTA_PERIOD_MS,
    })
  }

  function buildModelLines(ctx, configs) {
    var deduped = {}
    for (var i = 0; i < configs.length; i++) {
      var c = configs[i]
      var label = (typeof c.label === "string") ? c.label.trim() : ""
      if (!label) continue
      var qi = c.quotaInfo
      var frac = (qi && typeof qi.remainingFraction === "number") ? qi.remainingFraction : 0
      var rtime = (qi && qi.resetTime) || undefined
      var norm = normalizeLabel(label)
      var kd = modelKeyAndDisplay(norm)
      var key = kd.key
      if (!deduped[key] || frac < deduped[key].remainingFraction) {
        deduped[key] = {
          label: kd.display,
          remainingFraction: frac,
          resetTime: rtime,
        }
      }
    }

    var models = []
    var keys = Object.keys(deduped)
    for (var i = 0; i < keys.length; i++) {
      var m = deduped[keys[i]]
      m.sortKey = modelSortKey(m.label)
      models.push(m)
    }

    models.sort(function (a, b) {
      return a.sortKey < b.sortKey ? -1 : a.sortKey > b.sortKey ? 1 : 0
    })

    var lines = []
    for (var i = 0; i < models.length; i++) {
      lines.push(modelLine(ctx, models[i].label, models[i].remainingFraction, models[i].resetTime))
    }
    return lines
  }

  function readFirstStringDeep(value, keys) {
    if (!value || typeof value !== "object") return null

    for (var i = 0; i < keys.length; i++) {
      var direct = value[keys[i]]
      if (typeof direct === "string" && direct.trim()) return direct.trim()
    }

    var nested = Object.values(value)
    for (var j = 0; j < nested.length; j++) {
      var found = readFirstStringDeep(nested[j], keys)
      if (found) return found
    }
    return null
  }

  function mapTierToPlan(value) {
    if (!value) return null
    var normalized = String(value).trim().toLowerCase()
    if (!normalized) return null
    if (normalized.indexOf("ultra") !== -1) return "Ultra"
    if (normalized.indexOf("pro") !== -1) return "Pro"
    if (normalized.indexOf("free") !== -1) return "Free"
    if (normalized === "standard-tier") return "Paid"
    if (normalized === "legacy-tier") return "Legacy"
    if (normalized.indexOf("workspace") !== -1) return "Workspace"
    return null
  }

  function planRank(value) {
    var normalized = String(mapTierToPlan(value) || "").trim().toLowerCase()
    if (normalized === "ultra") return 3
    if (normalized === "pro") return 2
    if (normalized === "free") return 1
    return 0
  }

  function extractTierValue(data) {
    if (!data || typeof data !== "object") return null
    var paidTier = data.paidTier && typeof data.paidTier === "object" ? data.paidTier : null
    var currentTier = data.currentTier && typeof data.currentTier === "object" ? data.currentTier : null

    return (
      readFirstStringDeep(paidTier, ["id", "name", "slug", "quotaTier"]) ||
      readFirstStringDeep(currentTier, ["id", "name", "slug", "quotaTier"]) ||
      readFirstStringDeep(data, ["tier", "userTier", "subscriptionTier"])
    )
  }

  // --- Cloud Code API ---

  function probeCloudCode(ctx, token) {
    for (var i = 0; i < CLOUD_CODE_URLS.length; i++) {
      try {
        var resp = ctx.host.http.request({
          method: "POST",
          url: CLOUD_CODE_URLS[i] + FETCH_MODELS_PATH,
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + token,
            "User-Agent": "antigravity",
          },
          bodyText: "{}",
          timeoutMs: 15000,
        })
        if (ctx.util.isAuthStatus(resp.status)) return { _authFailed: true }
        if (resp.status >= 200 && resp.status < 300) {
          return ctx.util.tryParseJson(resp.bodyText)
        }
      } catch (e) {
        ctx.host.log.warn("Cloud Code request failed (" + CLOUD_CODE_URLS[i] + "): " + String(e))
      }
    }
    return null
  }

  function fetchCloudCodePlan(ctx, token) {
    for (var i = 0; i < CLOUD_CODE_URLS.length; i++) {
      try {
        var resp = ctx.host.http.request({
          method: "POST",
          url: CLOUD_CODE_URLS[i] + LOAD_CODE_ASSIST_PATH,
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + token,
            "User-Agent": "antigravity",
          },
          bodyText: JSON.stringify({ metadata: { ideType: "ANTIGRAVITY" } }),
          timeoutMs: 15000,
        })
        if (ctx.util.isAuthStatus(resp.status)) return { _authFailed: true }
        if (resp.status >= 200 && resp.status < 300) {
          var data = ctx.util.tryParseJson(resp.bodyText)
          return { plan: mapTierToPlan(extractTierValue(data)) }
        }
      } catch (e) {
        ctx.host.log.warn("Cloud Code plan request failed (" + CLOUD_CODE_URLS[i] + "): " + String(e))
      }
    }
    return null
  }

  function resolveCloudCodePlan(ctx, tokens, refreshTokenValue, allowRefresh, accountId) {
    for (var i = 0; i < tokens.length; i++) {
      var result = fetchCloudCodePlan(ctx, tokens[i])
      if (result && !result._authFailed && result.plan) {
        cachePlan(ctx, result.plan, accountId)
        return result.plan
      }
    }

    if (allowRefresh !== false && refreshTokenValue) {
      var refreshed = refreshAccessToken(ctx, refreshTokenValue)
      if (refreshed) {
        var refreshedResult = fetchCloudCodePlan(ctx, refreshed)
        if (refreshedResult && !refreshedResult._authFailed && refreshedResult.plan) {
          cachePlan(ctx, refreshedResult.plan, accountId)
          return refreshedResult.plan
        }
      }
    }

    return null
  }

  function parseCloudCodeModels(data) {
    var modelsObj = data && data.models
    if (!modelsObj || typeof modelsObj !== "object") return []
    var keys = Object.keys(modelsObj)
    var configs = []
    for (var i = 0; i < keys.length; i++) {
      var m = modelsObj[keys[i]]
      if (!m || typeof m !== "object") continue
      if (m.isInternal) continue
      var modelId = m.model || keys[i]
      if (CC_MODEL_BLACKLIST[modelId]) continue
      var displayName = (typeof m.displayName === "string") ? m.displayName.trim() : ""
      if (!displayName) continue
      var qi = m.quotaInfo
      var frac = (qi && typeof qi.remainingFraction === "number") ? qi.remainingFraction : 0
      var rtime = (qi && qi.resetTime) || undefined
      configs.push({
        label: displayName,
        quotaInfo: { remainingFraction: frac, resetTime: rtime },
      })
    }
    return configs
  }

  // --- LS probe ---

  function probeLs(ctx, apiKey, accountId, tokens, refreshTokenValue) {
    var discovery = discoverLs(ctx)
    if (!discovery) return null

    var found = findWorkingPort(ctx, discovery)
    if (!found) return null

    ctx.host.log.info("using LS at " + found.scheme + "://127.0.0.1:" + found.port)

    var metadata = {
      ideName: "antigravity",
      extensionName: "antigravity",
      ideVersion: "unknown",
      locale: "en",
    }
    if (apiKey) metadata.apiKey = apiKey

    // Try GetUserStatus first, fall back to GetCommandModelConfigs
    var data = null
    try {
      data = callLs(ctx, found.port, found.scheme, discovery.csrf, "GetUserStatus", { metadata: metadata })
    } catch (e) {
      ctx.host.log.warn("GetUserStatus threw: " + String(e))
    }
    var hasUserStatus = data && data.userStatus

    if (!hasUserStatus) {
      ctx.host.log.warn("GetUserStatus failed, trying GetCommandModelConfigs")
      data = callLs(ctx, found.port, found.scheme, discovery.csrf, "GetCommandModelConfigs", { metadata: metadata })
    }

    // Parse model configs
    var configs
    if (hasUserStatus) {
      configs = (data.userStatus.cascadeModelConfigData || {}).clientModelConfigs || []
    } else if (data && data.clientModelConfigs) {
      configs = data.clientModelConfigs
    } else {
      return null
    }

    var filtered = []
    for (var j = 0; j < configs.length; j++) {
      var mid = configs[j].modelOrAlias && configs[j].modelOrAlias.model
      if (mid && CC_MODEL_BLACKLIST[mid]) continue
      filtered.push(configs[j])
    }

    var lines = buildModelLines(ctx, filtered)
    if (lines.length === 0) return null

    var plan = null
    if (hasUserStatus) {
      var ps = data.userStatus.planStatus || {}
      var pi = ps.planInfo || {}
      plan = pi.planName || null
      var cachedOverridePlan = loadCachedPlan(ctx, accountId)
      if (planRank(cachedOverridePlan) > planRank(plan)) {
        plan = cachedOverridePlan
      }
    } else {
      plan = resolveCloudCodePlan(ctx, tokens || [], refreshTokenValue, true, accountId)
    }

    return { plan: plan, lines: lines }
  }

  // --- Probe ---

  function probe(ctx) {
    var auth = loadAuthStatus(ctx)
    var apiKey = auth && typeof auth.apiKey === "string" ? auth.apiKey : null
    var accountId = normalizeAccountId(auth && auth.email)
    var proto = loadProtoTokens(ctx)
    var tokens = collectTokens(ctx, apiKey, proto)

    var lsResult = probeLs(ctx, apiKey, accountId, tokens, proto && proto.refreshToken)
    if (lsResult) return lsResult

    if (tokens.length === 0) throw "Start Antigravity and try again."

    var ccData = null
    var cloudPlan = null
    var winningToken = null
    for (var i = 0; i < tokens.length; i++) {
      ccData = probeCloudCode(ctx, tokens[i])
      if (ccData && !ccData._authFailed) {
        winningToken = tokens[i]
        break
      }
      ccData = null
    }

    if (!ccData && proto && proto.refreshToken) {
      var refreshed = refreshAccessToken(ctx, proto.refreshToken)
      if (refreshed) {
        ccData = probeCloudCode(ctx, refreshed)
        if (ccData && !ccData._authFailed) winningToken = refreshed
      }
    }

    if (ccData && !ccData._authFailed) {
      var configs = parseCloudCodeModels(ccData)
      var lines = buildModelLines(ctx, configs)
      if (lines.length > 0) {
        cloudPlan = resolveCloudCodePlan(
          ctx,
          winningToken ? [winningToken] : tokens,
          proto && proto.refreshToken,
          true,
          accountId
        )
        return { plan: cloudPlan, lines: lines }
      }
    }

    throw "Start Antigravity and try again."
  }

  globalThis.__openusage_plugin = { id: "antigravity", probe: probe }
})()
