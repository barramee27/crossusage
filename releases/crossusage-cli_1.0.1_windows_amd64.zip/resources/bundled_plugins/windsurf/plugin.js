(function () {
  var LS_SERVICE = "exa.language_server_pb.LanguageServerService"
  var CLOUD_SERVICE = "exa.seat_management_pb.SeatManagementService"
  var CLOUD_URL = "https://server.codeium.com"

  // Windsurf variants — tried in order (Windsurf first, then Windsurf Next).
  // Markers use --ide_name exact matching in the Rust discover code.
  var VARIANTS = [
    {
      marker: "windsurf",
      ideName: "windsurf",
      stateDb: "~/Library/Application Support/Windsurf/User/globalStorage/state.vscdb",
      appPlist: "/Applications/Windsurf.app/Contents/Info.plist",
    },
    {
      marker: "windsurf-next",
      ideName: "windsurf-next",
      stateDb: "~/Library/Application Support/Windsurf - Next/User/globalStorage/state.vscdb",
      appPlist: "/Applications/Windsurf - Next.app/Contents/Info.plist",
    },
  ]

  function getWindsurfStateDb(ctx, variant) {
    var home = ctx.host.fs.homeDir
    if (!home && ctx.app && ctx.app.appDataDir) {
      var m = String(ctx.app.appDataDir).match(/^(.+)\/\.local\/share\/[^/]+$/)
      if (m) home = m[1]
    }
    var macPaths = variant.marker === "windsurf-next"
      ? ["~/Library/Application Support/Windsurf - Next/User/globalStorage/state.vscdb"]
      : ["~/Library/Application Support/Windsurf/User/globalStorage/state.vscdb"]
    var linuxPaths = variant.marker === "windsurf-next"
      ? ["~/.config/Windsurf - Next/User/globalStorage/state.vscdb"]
      : ["~/.config/Windsurf/User/globalStorage/state.vscdb"]
    var winPaths = variant.marker === "windsurf-next"
      ? ["~/AppData/Roaming/Windsurf - Next/User/globalStorage/state.vscdb"]
      : ["~/AppData/Roaming/Windsurf/User/globalStorage/state.vscdb"]
    var all = macPaths.concat(linuxPaths).concat(winPaths)
    for (var i = 0; i < all.length; i++) {
      if (ctx.host.fs.exists(all[i])) return all[i]
    }
    if (home) {
      var linuxAbs = variant.marker === "windsurf-next"
        ? home + "/.config/Windsurf - Next/User/globalStorage/state.vscdb"
        : home + "/.config/Windsurf/User/globalStorage/state.vscdb"
      var macAbs = variant.marker === "windsurf-next"
        ? home + "/Library/Application Support/Windsurf - Next/User/globalStorage/state.vscdb"
        : home + "/Library/Application Support/Windsurf/User/globalStorage/state.vscdb"
      var winAbs = variant.marker === "windsurf-next"
        ? home + "/AppData/Roaming/Windsurf - Next/User/globalStorage/state.vscdb"
        : home + "/AppData/Roaming/Windsurf/User/globalStorage/state.vscdb"
      if (ctx.host.fs.exists(linuxAbs)) return linuxAbs
      if (ctx.host.fs.exists(macAbs)) return macAbs
      if (ctx.host.fs.exists(winAbs)) return winAbs
    }
    return macPaths[0]
  }

  // --- LS discovery ---

  function discoverLs(ctx, variant) {
    return ctx.host.ls.discover({
      processName: "language_server",
      markers: [variant.marker],
      csrfFlag: "--csrf_token",
      portFlag: "--extension_server_port",
      extraFlags: ["--windsurf_version"],
    })
  }

  function loadApiKey(ctx, variant) {
    try {
      var stateDb = getWindsurfStateDb(ctx, variant)
      var rows = ctx.host.sqlite.query(
        stateDb,
        "SELECT value FROM ItemTable WHERE key = 'windsurfAuthStatus' LIMIT 1"
      )
      var parsed = ctx.util.tryParseJson(rows)
      if (!parsed || !parsed.length || !parsed[0].value) return null
      var auth = ctx.util.tryParseJson(parsed[0].value)
      if (!auth || !auth.apiKey) return null
      return auth.apiKey
    } catch (e) {
      ctx.host.log.warn("failed to read API key from " + variant.marker + ": " + String(e))
      return null
    }
  }

  function loadInstalledVersion(ctx, variant) {
    var path = variant && variant.appPlist
    if (!path) return null
    try {
      if (!ctx.host.fs || !ctx.host.fs.exists || !ctx.host.fs.readText) return null
      if (!ctx.host.fs.exists(path)) return null
      var text = ctx.host.fs.readText(path)
      if (!text) return null
      var match = String(text).match(/<key>CFBundleShortVersionString<\/key>\s*<string>([^<]+)<\/string>/)
      if (!match || !match[1]) return null
      return String(match[1]).trim() || null
    } catch (e) {
      ctx.host.log.warn("failed to read installed version for " + variant.marker + ": " + String(e))
      return null
    }
  }

  function probePort(ctx, scheme, port, csrf, ideName) {
    ctx.host.http.request({
      method: "POST",
      url: scheme + "://127.0.0.1:" + port + "/" + LS_SERVICE + "/GetUnleashData",
      headers: {
        "Content-Type": "application/json",
        "Connect-Protocol-Version": "1",
        "x-codeium-csrf-token": csrf,
      },
      bodyText: JSON.stringify({
        context: {
          properties: {
            devMode: "false",
            extensionVersion: "unknown",
            ide: ideName,
            ideVersion: "unknown",
            os: "macos",
          },
        },
      }),
      timeoutMs: 5000,
      dangerouslyIgnoreTls: scheme === "https",
    })
    return true
  }

  function findWorkingPort(ctx, discovery, ideName) {
    var ports = discovery.ports || []
    for (var i = 0; i < ports.length; i++) {
      var port = ports[i]
      try { if (probePort(ctx, "https", port, discovery.csrf, ideName)) return { port: port, scheme: "https" } } catch (e) { /* ignore */ }
      try { if (probePort(ctx, "http", port, discovery.csrf, ideName)) return { port: port, scheme: "http" } } catch (e) { /* ignore */ }
      ctx.host.log.info("port " + port + " probe failed on both schemes")
    }
    if (discovery.extensionPort) return { port: discovery.extensionPort, scheme: "http" }
    return null
  }

  function callLs(ctx, port, scheme, csrf, method, body) {
    var resp = ctx.host.http.request({
      method: "POST",
      url: scheme + "://127.0.0.1:" + port + "/" + LS_SERVICE + "/" + method,
      headers: {
        "Content-Type": "application/json",
        "Connect-Protocol-Version": "1",
        "x-codeium-csrf-token": csrf,
      },
      bodyText: JSON.stringify(body || {}),
      timeoutMs: 10000,
      dangerouslyIgnoreTls: scheme === "https",
    })
    if (resp.status < 200 || resp.status >= 300) {
      ctx.host.log.warn("callLs " + method + " returned " + resp.status)
      return null
    }
    return ctx.util.tryParseJson(resp.bodyText)
  }

  // --- Credit line builder ---

  function creditLine(ctx, label, used, total, resetsAt, periodMs) {
    if (typeof total !== "number" || total <= 0) return null
    if (typeof used !== "number") used = 0
    if (used < 0) used = 0
    var line = {
      label: label,
      used: used,
      limit: total,
      format: { kind: "count", suffix: "credits" },
    }
    if (resetsAt) line.resetsAt = resetsAt
    if (periodMs) line.periodDurationMs = periodMs
    return ctx.line.progress(line)
  }

  function billingPeriodMs(planStart, planEnd) {
    if (!planStart || !planEnd) return null
    var startMs = Date.parse(planStart)
    var endMs = Date.parse(planEnd)
    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) return null
    return endMs - startMs
  }

  function buildPlanLines(ctx, userStatus) {
    var ps = (userStatus && userStatus.planStatus) || {}
    var pi = ps.planInfo || {}
    var plan = pi.planName || null
    var planEnd = ps.planEnd || null
    var periodMs = billingPeriodMs(ps.planStart || null, planEnd)

    var lines = []

    var promptTotal = ps.availablePromptCredits
    var promptUsed = ps.usedPromptCredits || 0
    if (typeof promptTotal === "number" && promptTotal > 0) {
      var pl = creditLine(ctx, "Prompt credits", promptUsed / 100, promptTotal / 100, planEnd, periodMs)
      if (pl) lines.push(pl)
    }

    var flexTotal = ps.availableFlexCredits
    var flexUsed = ps.usedFlexCredits || 0
    if (typeof flexTotal === "number" && flexTotal > 0) {
      var xl = creditLine(ctx, "Flex credits", flexUsed / 100, flexTotal / 100, null, null)
      if (xl) lines.push(xl)
    }

    if (lines.length === 0) {
      lines.push(ctx.line.badge({ label: "Credits", text: "Unlimited" }))
    }

    return { plan: plan, lines: lines }
  }

  // --- LS probe for a specific variant ---

  function probeVariant(ctx, variant) {
    var discovery = discoverLs(ctx, variant)
    if (!discovery) return null

    var found = findWorkingPort(ctx, discovery, variant.ideName)
    if (!found) return null

    var apiKey = loadApiKey(ctx, variant)
    if (!apiKey) {
      ctx.host.log.warn("no API key found in SQLite for " + variant.marker)
      return null
    }

    var version = (discovery.extra && discovery.extra.windsurf_version) || "unknown"

    var metadata = {
      apiKey: apiKey,
      ideName: variant.ideName,
      ideVersion: version,
      extensionName: variant.ideName,
      extensionVersion: version,
      locale: "en",
    }

    var data = null
    try {
      data = callLs(ctx, found.port, found.scheme, discovery.csrf, "GetUserStatus", { metadata: metadata })
    } catch (e) {
      ctx.host.log.warn("GetUserStatus threw for " + variant.marker + ": " + String(e))
    }

    if (!data || !data.userStatus) return null

    return buildPlanLines(ctx, data.userStatus)
  }

  // --- Cloud fallback ---

  function callCloud(ctx, apiKey, variant) {
    var appVersion = loadInstalledVersion(ctx, variant) || "0.0.0"
    try {
      var resp = ctx.host.http.request({
        method: "POST",
        url: CLOUD_URL + "/" + CLOUD_SERVICE + "/GetUserStatus",
        headers: {
          "Content-Type": "application/json",
          "Connect-Protocol-Version": "1",
        },
        bodyText: JSON.stringify({
          metadata: {
            apiKey: apiKey,
            ideName: variant.ideName,
            ideVersion: appVersion,
            extensionName: variant.ideName,
            extensionVersion: appVersion,
            locale: "en",
          },
        }),
        timeoutMs: 15000,
      })
      if (resp.status >= 200 && resp.status < 300) {
        return ctx.util.tryParseJson(resp.bodyText)
      }
    } catch (e) {
      ctx.host.log.warn("cloud request failed: " + String(e))
    }
    return null
  }

  function probeCloudVariant(ctx, variant) {
    var apiKey = loadApiKey(ctx, variant)
    if (!apiKey) return null

    var data = callCloud(ctx, apiKey, variant)
    if (!data || !data.userStatus) return null

    return buildPlanLines(ctx, data.userStatus)
  }

  // --- Probe ---

  function probe(ctx) {
    for (var i = 0; i < VARIANTS.length; i++) {
      var result = probeVariant(ctx, VARIANTS[i])
      if (result) return result
    }

    for (var i = 0; i < VARIANTS.length; i++) {
      var result = probeCloudVariant(ctx, VARIANTS[i])
      if (result) return result
    }

    throw "Start Windsurf or sign in and try again."
  }

  globalThis.__openusage_plugin = { id: "windsurf", probe: probe }
})()
